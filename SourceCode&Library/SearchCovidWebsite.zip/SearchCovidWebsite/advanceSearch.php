<!DOCTYPE html>
<html>

<?php

//if have previous session, destroy it

session_start();
if (session_status() != PHP_SESSION_NONE){
	session_destroy();}
?>
<head>
	<title>Welcome to SearchCovid-19</title>

	<link rel="stylesheet" type="text/css" href="asset/css/style.css">
</head>
<body>

	<div class="wrapper indexPage">
		<div class="mainSection">

			<div class="logoContainer">
				<img src="searchcovidlogopng.png">
			</div>


			<div class="searchContainer">

				<form action="searchresults.php" method="POST">

                    <input class="searchBox" type="text" name="term">
                    <div class="checkboxes">
                        <input type="checkbox" name="check_list[]" value="popularity"><label>Most Popular</label> &nbsp; &nbsp;
                        <input type="checkbox" name="check_list[]" value="date"><label>Last 24 Hours</label> &nbsp; &nbsp;
                        <input type="checkbox" name="check_list[]" value="subtopics"><label>By subtopics</label>&nbsp; &nbsp;
                        <input type="checkbox" name="check_list[]" value="uselocation"><label>use location</label>
                    </div>
                    <div class="dropdown_lists">
                        <select name="classification">
                            <option value = "positive">Positive</option>
                            <option value = "negative">Negative</option>
                            <option value = "neutural">Neutral</option>
                            <option value = "default" selected=TRUE hidden=TRUE>Opinions</option>
                        </select> 
                        
                    </div>
					<input class="searchButton" type="submit" name="adsearch" value="Search">
				
				</form>
			</div>


		</div>

						  	
	</div>

</body>