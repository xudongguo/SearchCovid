<?php
class ResponseGetter{
   
   //encode querystr and params into url
   static function queryStrEncoder($queryStr, $params, $mlt, $subtopics){
       
        if ($subtopics==1){
       $url = 'http://localhost:8983/solr/SearchCovid/clustering?';

        } 
       else if($mlt==1){
           $url='http://localhost:8983/solr/SearchCovid/mlt?';
        }
       else{
        $url = 'http://localhost:8983/solr/SearchCovid/select?';}

        $url.=$queryStr.$params;
        //url encoding
        str_replace(array(',','+','(',')',':',' ','[',']','||'), array('%2C','%2B','%28','%29','%3A','%20','%5B','%5D','%7C'),$url);
        $to_post = array('q' => urlencode($queryStr),
                    'params'=> urlencode($params));
        foreach($to_post as $key=>$value) {
            $paramstring .= $key.'='.$value.'&';
        }
        
        rtrim($paramstring, '&');
        //print_r('URL-----');
        //print_r($url);
        return array($url,$to_post, $paramstring);

   }



   //get JsonResponse from url using curl
   public function getJsonResponse($queryStr,$params, $mlt, $subtopics){
       
     $encodedlist=$this->queryStrEncoder($queryStr,$params,$mlt,$subtopics);
     $url=$encodedlist[0];
     $to_post=$encodedlist[1];
     $paramstring=$encodedlist[2];

      try
     { 
    //create curl socket to get response json
     $ch = curl_init();
     curl_setopt($ch,CURLOPT_URL,$url);
     curl_setopt($ch,CURLOPT_POST,count($to_post));
     curl_setopt($ch,CURLOPT_POSTFIELDS,$paramstring);
     curl_setopt($ch,CURLOPT_RETURNTRANSFER, TRUE);
     //get results
     $results = curl_exec($ch);
     curl_close($ch);
   
      }
      catch (Exception $e)
     {
     echo 'exception';
     print_r($e);
       //die("<html><head><title>SEARCH EXCEPTION</title><body><pre>{$e->__toString()}</pre></body></html>");
     }

        //parse results
        $jsonstring = $results; //your string
        $jsonstring = str_replace('\n', '', $jsonstring);
        $jsonstring = rtrim($jsonstring, ',');
        $jsonstring = "[" . trim($jsonstring) . "]";

        $results= json_decode($jsonstring,true)[0];
        return $results;

   }
   


}



?>