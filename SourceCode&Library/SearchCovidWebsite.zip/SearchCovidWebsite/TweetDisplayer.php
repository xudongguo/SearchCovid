

<?php 

session_start();

class TweetDisplayer{
    /*$results;
    public function setResult($tweetresults){
      $results=$tweetresults;
    }*/
    public function display($tweet){ 

                    // show tweets
                $profile_photo=$tweet['user.bigger_profile_url'][0];
                $name=$tweet['user.name'];
                $screen_name=$tweet['user.screen_name'];
                // show a tweet
                echo "<div class='overflow-hidden'>";
                    
                    // show picture
                    echo "<div class='tweet-image'>";
                    echo "<img src='{$profile_photo}' class='img-thumbnail' />";
                    echo "</div>";
                    
                    // show tweet content
                    echo "<div class='mainregion'>";
                        
                        // show name and screen name
                        echo "<h4 class='margin-top-4px'>";
                            echo "<a href='https://twitter.com/{$screen_name}'>{$name}</a> ";
                            echo "<span class='color-gray'>@{$screen_name}</span>";
                        echo "</h4>";
                        
                        // show tweet text
                        echo "<div class='full-text'>";
                        
                            // get tweet text
                            $tweet_text=$tweet['full_text'][0];
                            // make links clickable
                            $tweet_text=preg_replace('@(https?://([-\w\.]+)+(/([\w/_\.]*(\?\S+)?(#\S+)?)?)?)@', '<a href="$1" target="_blank">$1</a>', $tweet_text);
                            // output text
                            echo $tweet_text;
                        echo "</div>";
                    echo "</div>";

                    $fav_count=$tweet['favorite_count'][0];
                    $retweeted_count=$tweet['retweeted_count'][0];
                    $createdtime=$this->prettydate($tweet['created_at'][0]);
                    $twitterid=$tweet['id'];
                    array_push($_SESSION['IDS'],$twitterid);
                    // show numbers
                    echo "<div class='peripheralregion'>";
                    
                        // show number of tweets
                        echo "<div class='float-left margin-right-2em text-align-center'>";
                            echo "<div class='color-gray'>Likes: ".number_format($fav_count, 0, '.', ',')." </div>";
                            echo "<div class='badge font-size-20px'>"."</div>";
                        echo "</div>";
                        
                        // show number of followers
                        echo "<div class='float-left margin-right-2em text-align-center'>";
                            echo "<div class='color-gray'>Retweets: ".number_format($retweeted_count, 0, '.', ',')." </div>";
                            echo "<div class='badge font-size-20px'>"."</div>";
                        //show time sent
                        

                        //show mlt button
                        
                        echo "<div class='mlt'>";
                        //no mlt will be displayed if clustering is selected
                        if ($_SESSION['subtopics']==0){
                        echo "<form action=";
                        echo $_SERVER['PHP_SELF'];
                        echo " method='POST'>";
                        echo "<input class='mltSearchButton' type='submit' name=".$twitterid." value='more like this'>";
                        echo "</form>";}
                        echo "<div id='created-time' class='right'>".$createdtime."</div>";
                        echo "</div>";
                        
                    echo "</div>";
                    echo "<hr />";
                echo "</div>";
                echo "<hr />";
    }
        

    static function prettyDate($rawtime){
        $date = substr($rawtime,0,10);
        $time = substr($rawtime,11,8);
        $datetimestr='Sent at: '.$date.', '.$time;
        return $datetimestr;
    }
}
?>

