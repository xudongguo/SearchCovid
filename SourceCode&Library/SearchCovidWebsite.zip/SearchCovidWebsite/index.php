<!DOCTYPE html>
<?php

//if have previous session, destroy it

session_start();
if (session_status() != PHP_SESSION_NONE){
	session_destroy();}
?>
<html>
<head>
	<title>Welcome to SearchCovid-19</title>

	<link rel="stylesheet" type="text/css" href="asset/css/style.css">
</head>
<body>

	<div class="wrapper indexPage">
		<div class="mainSection">

			<div class="logoContainer">
				<img src="searchcovidlogopng.png">
			</div>


			<div class="searchContainer">

				<form action="searchresults.php" method="GET">

					<input class="searchBox" type="text" name="term">
					<input class="searchButton" type="submit" value="Search">
				
				</form>

				<form action="advanceSearch.php" method="GET">
					<input class="searchButton" type="submit" name="advance" value="Advance Search">
				</form>
			</div>


		</div>

						  	
	</div>

</body>