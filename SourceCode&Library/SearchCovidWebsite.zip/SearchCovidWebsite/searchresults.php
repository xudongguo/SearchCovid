<?php
  session_start();
//start php session if no previous session

error_reporting(E_ERROR | E_WARNING | E_PARSE);

// make sure browsers see this page as utf-8 encoded HTML
header('Content-Type: text/html; charset=utf-8');

//===============================CHECK START CONDITION:==========================================
 // 1. WHETHER 'MORE LIKE THIS' BUTTON IS CLICKED, 2. WHETHER NEXT PAGE OR PREVIOUS IS CLICKED, 3.WHETHER ADVANCE SEARCH IS SELECTED
  
 //1. more like this button is clicked OR is already in mlt mode, reload session variable

 if (isset($_SESSION['IDS']) ||isset($_SESSION['mltID'])) {

  foreach($_SESSION['IDS'] as $ID){
    
    //reset offset
    isset($_SESSION['offset'])?$_SESSION['offset']:0;

        //first time mlt 
        if($_POST[$ID]){
          $tweetIDclicked=$ID;
          $_SESSION['mltID']=$tweetIDclicked;
          
          $_SESSION['offset']=0;
          $_POST[$ID]=false;
          
          $mlt=$_SESSION['mlt']=1;
          $_SESSION['uselocation']=$location=0; 

          $content = $_SESSION['content']; 
          $popularity=$_SESSION['popularity'];
          $date=$_SESSION['date'];
          $subtopics=$_SESSION['subtopics'];
          $classification_selected=$_SESSION['classification_selected'];
          $classification=$_SESSION['classification'];
        break;
        }
              //page 2 onwards of mlt
        else if (isset($_SESSION['mltID'])){
            $tweetIDclicked=$_SESSION['mltID'];
            
            $mlt=$_SESSION['mlt']=1;
            $_SESSION['uselocation']=$location=0; 
          }

   
    }


  }

   //2. if is following pages, reload page variable
  if ($_SESSION['page']>1){
    $mlt = $_SESSION['mlt'];
    $location=$_SESSION['uselocation'];

    $content = $_SESSION['content']; 
    $popularity=$_SESSION['popularity'];
    $date=$_SESSION['date'];
    $subtopics=$_SESSION['subtopics'];
    $classification_selected=$_SESSION['classification_selected'];
    $classification=$_SESSION['classification'];
}





  //3. is normal or advance search and is first page
  else if ($_SESSION['mlt']!=1){
    //set &mlt to 0
    $mlt=0;
    $tweetIDclicked=NULL;
    $subtopics=0;
    //check normal search field
    if(!empty($_GET['term'])){
        $content = $_GET['term'];
    }

    //check advanced search
    else if(!empty($_POST['term'])){
      if(($_POST['adsearch'])){
        $content = $_POST['term'];
        if(!empty($_POST['check_list'])) {
          // Counting number of checked checkboxes.
          $checked_count = count($_POST['check_list']);
          foreach($_POST['check_list'] as $selected){
              if ($selected == 'popularity'){
                  $popularity = 1;
              }
              if ($selected == 'date'){
                  $date = 1;
              }
              if ($selected == 'subtopics'){
                  $subtopics = 1;
              }
              if ($selected=='uselocation'){
                 $location=1;
              }
          }
          $classification = $_POST['classification'];
          
          if ($classification != 'default') {
              $classification_selected = 1;
          }


        }
      }
    }
    //search box empty reload search page
    else{ 
      header("location:javascript://history.go(-1)");

    }
  }
  
  //====================================ASSIGN SESSION VARIABLE TO TEMP VARIABLES=============================
  //strip white space of query string
  $content = preg_replace('/\s+/', '||', $content);

  $_SESSION['content']=$content;
  $_SESSION['popularity']=$popularity;
  $_SESSION['mlt']=$mlt;
  $_SESSION['date']=$date;
  $_SESSION['subtopics']=$subtopics;
  $_SESSION['classification_selected']=$classification_selected;
  $_SESSION['classification']=$classification;
  $_SESSION['uselocation']=$location;
 $query = isset($_REQUEST['q']) ? $_REQUEST['q'] : false;
 $results = false;


 //==================================PREPARE SOLR CLIENT======================================
 if (!$query)
 {
  // The Apache Solr Client library should be on the include path
  // which is usually most easily accomplished by placing in the
  // same directory as this script ( . or current directory is a default
  // php include path entry in the php.ini)
  require_once('Apache/Solr/Service.php');
  // create a new solr service instance - host, port, and webapp
  // path (all defaults in this example)
  $solr = new Apache_Solr_Service('localhost', 8983, '/solr/SearchCovid');
  if ( ! $solr->ping() ) 
  {
    echo 'Solr service not responding.';
    exit;
  }
  else
  {
    //echo ('-----Solr connection succuessful-----');
  }
  // if magic quotes is enabled then stripslashes will be needed
  if (get_magic_quotes_gpc() == 1)
  {
    $query = stripslashes($query);
  }

//search parameters for solr

  if(!isset($_SESSION['offset']))
  {
    $_SESSION['offset']=0;
  }
  //======================================INIT SEARCH PARAMETERS========================================
  $offset = 0 ;
  $limit = 10;
  $rows=$limit;
  //sort params
  $sort=false;
  $sortfav ='';
  $sortret='';
  //fq params
  $fqdate='';
  $fqgeo='';
  //classification
  $fqpolarity='';
  //subtopic params
  //param list
  $params='';

  //init queryStr
  $queryStr='q=full_text%3A'.$content.'%20user.screen_name%3A'.$content;
  //configure search paramters for different advanced search options

  if ($date==1){ 
    //$queryStr=$queryStr.'+created_at%3A[NOW-24HOURS%20TO%20NOW]';
    $fqdate='created_at%3A[NOW-24HOURS%20TO%20NOW]';
  }

  if ($popularity==1){
    $sortfav='favorite_count%20desc';
    $sortret= 'retweeted_count%20desc';
    $sort=true;
  }

  if ($classification_selected==1){
     $fqpolarity='polarity%3A'.strtolower($classification);
  }
  //filter query 
  if ($location==1){
    $fqgeo = 'full_text%3A';
    //get user location and put into fq param
    $query = @unserialize (file_get_contents('http://ip-api.com/php/'));
    if ($query && $query['status'] == 'success') {
      $country=$query['country'];
      $city=$query['city'];
    }
    //print_r ($city);
    //print_r ($country);
     $fqgeo.=$city."%20".$country;
  }

  //if 'more like this' is set
  if ($mlt==1){
    //append target tweetid to query string
    $queryStr.='%20id:'.$tweetIDclicked;
  }

  if($subtopics==1){
    //only cluster the top 100 results for performance
    $rows=100;
  }

  if ($sort){
      $params.='&sort='.$sortfav.','.$sortret;
      $sort=false;
  }

  //append params to param list
  $queryStr.='&start='.$_SESSION['offset'].'&rows='.$rows;
  $params.='&fq='.$fqdate.'&fq='.$fqgeo.'&fq='.$fqpolarity.'&wt=json';
  /**debug */
  //print_r($queryStr);
  //echo'PARAMS';
  //print_r($params);

  }
//session_destroy();
?>


<?php
//=======================================GET & DISPLAY RESULT=================================
echo "<html>";
echo  "<head>";
echo    "<title>Results</title>";
echo   "<link rel='stylesheet' type='text/css' href='asset/css/style.css'>";
echo  "</head>";
echo  "<body>";
echo  "<div class='wrapper resultpage'>";
echo  "<div class='searchResults'>";
echo "<div class='hero-image'>" ;
  echo "<div class='hero-text'>";
    echo"<h1 style='font-size:50px'>SearchCovid</h1>";
    echo "<h3 style= 'color:white'>grab the latest tweets about COVID-19</h3>";
  echo "</div>";
echo "</div>";

 //reset POST and array of twitterids
$_SESSION['IDS']=array();
$_POST=array();
//get response
require_once('ResponseGetter.php');
$responsegetter=new ResponseGetter();
$resultarray=$responsegetter->getJsonResponse($queryStr,$params,$mlt,$subtopics);
$response=$resultarray['response'];
/*tweet array*/
$tweets=$response['docs'];   

//=====================================INIT PAGING PARAMETERS=============================
$querytime=$resultarray['responseHeader']['QTime'];
$total = (int) $response['numFound'];

//handle not found
if ($total==0){
  echo "<h4 style='text-align:center'> Nothing is found <a href='index.php'>Try something else!</a></h4>";
}

else{

    if ($total<$limit){
      $limit=$total;
    }

    $pages = intval($total/$limit);

    //current page
    $page = min($pages, filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, array(
      'options' => array(
          'default'   => 1,
          'min_range' => 1,
      ),
    )));


    $offset = ($page-1)  * $limit;
    $start = $offset+1;
    $end = min(($offset + $limit), $total);
    $_SESSION['page']=$page;
    $_SESSION['page']++;
    $_SESSION['offset']=$offset+$limit;
    //=========================================DISPLAY TWEETS============================================
    require_once('TweetDisplayer.php');
    $tweetdisplayer=new TweetDisplayer();
    echo "<h4>fetched ".$total." tweets, took about ".strval(intval($querytime)/1000)." seconds </h4>";
    echo "<hr />";

    //display by clusters if subtopic is set
    if ($subtopics==1){
      $clusters=$resultarray['clusters'];
      foreach($clusters as $cluster){
        $label=$cluster['labels'][0];
        //display subtopic label   
        echo "<div id='gradlabel' class='labels'> <h3 id='subtopic'>Subtopic: ".$label."</h3></div>" ;
        echo "<hr />";
        $clustertweetsIDs=$cluster['docs'];
        //display tweets in each subopic
        foreach ($clustertweetsIDs as $ID){
          foreach ($tweets as $tweet){
            if ($tweet['id']==$ID){
            $tweetdisplayer->display($tweet);}
          }
        }
      }
    }

    else{
        foreach($tweets as $tweet){
          $tweetdisplayer->display($tweet);
        //display pagination selector
        }
      
        // backward link
        $prevlink = ($page > 1) ? '<a href="?page=1" title="First page">&laquo;</a> <a href="?page=' . ($page - 1) . '" title="Previous page">&lsaquo;</a>' : '<span class="disabled">&laquo;</span> <span class="disabled">&lsaquo;</span>';

        // The "forward" link
        $nextlink = ($page < $pages) ? '<a href="?page=' . ($page + 1) . '" title="Next page">&rsaquo;</a> <a href="?page=' . $pages . '" title="Last page">&raquo;</a>' : '<span class="disabled">&rsaquo;</span> <span class="disabled">&raquo;</span>';
        //display paging info
        echo '<div id="paging"><p>', $prevlink, ' Page ', $page, ' of ', $pages, ' pages, displaying ', $start."-".$end." of ".$total." tweets ", $nextlink, ' </p></div>'; 
        } 

      echo" </div>" ;
      echo  "</div>";
    echo   "</body>";
    echo "</html>";
  }





?>